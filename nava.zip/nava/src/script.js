const schedule = [
  { id: 1, name: "Breakfast", icon: "🍳", start: "07:00", end: "07:30", duration: "30:00", isBreak: true },
  { id: 2, name: "1st Period", icon: "📚", start: "07:30", end: "08:25", duration: "55:00", isBreak: false },
  { id: 3, name: "2nd Period", icon: "📖", start: "08:25", end: "09:20", duration: "55:00", isBreak: false },
  { id: 4, name: "Coffee Break", icon: "☕", start: "09:20", end: "09:35", duration: "15:00", isBreak: true },
  { id: 5, name: "3rd Period", icon: "📝", start: "09:35", end: "10:30", duration: "55:00", isBreak: false },
  { id: 6, name: "4th Period", icon: "🔬", start: "10:30", end: "11:25", duration: "55:00", isBreak: false },
  { id: 7, name: "Lunch Break", icon: "🍽️", start: "11:25", end: "12:00", duration: "35:00", isBreak: true },
  { id: 8, name: "5th Period", icon: "💻", start: "12:00", end: "12:55", duration: "55:00", isBreak: false },
  { id: 9, name: "Coffee Break", icon: "☕", start: "12:55", end: "13:20", duration: "25:00", isBreak: true },
  { id: 10, name: "6th Period", icon: "🔧", start: "13:20", end: "14:15", duration: "55:00", isBreak: false },
  { id: 11, name: "7th Period", icon: "🎓", start: "14:15", end: "15:10", duration: "55:00", isBreak: false }
];

let currentSelectedCohort = 'ALL';
let dismissedSessionIndex = -1;

function dismissBanner() {
  const now = new Date();
  schedule.forEach((item, index) => {
    const start = parseTime(item.start);
    const end = parseTime(item.end);
    if (now >= start && now < end) {
      dismissedSessionIndex = index;
    }
  });
  document.getElementById('attendance-alert').style.display = 'none';
}

function parseTime(timeStr) {
  const [hours, minutes] = timeStr.split(':').map(Number);
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes, 0);
}

function formatTimeRemaining(ms) {
  if (ms <= 0) return "00:00";
  const totalSec = Math.floor(ms / 1000);
  const hrs = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;

  if (hrs > 0) {
    return `${hrs}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function formatAmPm(timeStr) {
  const [h, m] = timeStr.split(':').map(Number);
  const period = h >= 12 ? 'PM' : 'AM';
  const adjustedHour = h % 12 || 12;
  return `${adjustedHour}:${String(m).padStart(2, '0')} ${period}`;
}

function renderTable() {
  const tbody = document.getElementById('schedule-body');
  tbody.innerHTML = schedule.map((item, index) => `
    <tr id="row-${index}">
      <td>
        <div class="session-badge-cell ${item.isBreak ? 'session-type-break' : 'session-type-class'}">
          <span style="font-size: 1.2rem;">${item.icon}</span>
          <span>${item.name}</span>
        </div>
      </td>
      <td>${formatAmPm(item.start)}</td>
      <td>${formatAmPm(item.end)}</td>
      <td>${item.duration}</td>
      <td id="status-${index}" style="color: var(--text-muted); font-size: 0.85rem;">--</td>
    </tr>
  `).join('');
}

function setCohortView(cohort) {
  currentSelectedCohort = cohort;
  
  const buttons = document.querySelectorAll('.filter-btn');
  buttons.forEach(btn => {
    if (btn.textContent.includes(cohort) || (cohort === 'ALL' && btn.textContent.includes('All'))) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  renderClassrooms();
}

function renderClassrooms() {
  const container = document.getElementById('rooms-container');
  const now = new Date();
  const start4th = parseTime("10:30");
  const end4th = parseTime("11:25");
  const is4thPeriod = (now >= start4th && now < end4th);

  const cohortsData = [
    {
      id: "LGO-03",
      standardRoom: "Room 3.05",
      currentRoom: "Room 3.05",
      badge: "All Day",
      note: "Fixed location all day.",
      isSwapActive: false
    },
    {
      id: "LGO-04",
      standardRoom: "Room 3.06",
      currentRoom: is4thPeriod ? "Room 2.14" : "Room 3.06",
      badge: is4thPeriod ? "⚡ Active Now (4th Period)" : "Standard Room",
      note: is4thPeriod ? "Moved to Room 2.14 for 4th Period only" : "All Day in 3.06 (Except 4th Period in 2.14)",
      isSwapActive: is4thPeriod
    },
    {
      id: "LGO-05",
      standardRoom: "Room 3.08",
      currentRoom: is4thPeriod ? "Room 1.12" : "Room 3.08",
      badge: is4thPeriod ? "⚡ Active Now (4th Period)" : "Standard Room",
      note: is4thPeriod ? "Moved to Room 1.12 for 4th Period only" : "All Day in 3.08 (Except 4th Period in 1.12)",
      isSwapActive: is4thPeriod
    },
    {
      id: "SCGO-05",
      standardRoom: "Room 3.03",
      currentRoom: "Room 3.03",
      badge: "All Day",
      note: "Fixed location all day.",
      isSwapActive: false
    }
  ];

  if (currentSelectedCohort === 'ALL') {
    container.innerHTML = cohortsData.map(c => `
      <div class="room-card ${c.isSwapActive ? 'active-swap' : ''}">
        <div class="room-header">
          <span class="room-cohort">${c.id}</span>
          <span class="room-badge">${c.badge}</span>
        </div>
        <div class="room-number">${c.currentRoom}</div>
        <div class="room-note">${c.note}</div>
      </div>
    `).join('');
  } else {
    const item = cohortsData.find(c => c.id === currentSelectedCohort);
    if (item) {
      container.innerHTML = `
        <div class="room-card single-view ${item.isSwapActive ? 'active-swap' : ''}">
          <div class="room-header">
            <div>
              <span class="room-cohort">${item.id} — Current Assigned Classroom</span>
              <div class="room-note" style="margin-top: 4px; font-size: 0.9rem;">${item.note}</div>
            </div>
            <span class="room-badge" style="font-size: 0.85rem; padding: 6px 14px;">${item.badge}</span>
          </div>
          <div class="room-number" style="margin-top: 10px;">${item.currentRoom}</div>
        </div>
      `;
    }
  }
}

function updateDashboard() {
  const now = new Date();

  const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
  document.getElementById('date-display').textContent = now.toLocaleDateString('en-US', options);
  document.getElementById('clock-display').textContent = now.toLocaleTimeString('en-US');

  let currentIdx = -1;
  let nextIdx = -1;

  schedule.forEach((item, index) => {
    const start = parseTime(item.start);
    const end = parseTime(item.end);
    const row = document.getElementById(`row-${index}`);
    const statusCell = document.getElementById(`status-${index}`);

    if (now >= start && now < end) {
      currentIdx = index;
      nextIdx = index + 1 < schedule.length ? index + 1 : -1;
      row.className = "current-session";
      statusCell.innerHTML = `<span style="color: var(--accent); font-weight: 700;">Ongoing ⚡</span>`;
    } else if (now >= end) {
      row.className = "";
      statusCell.textContent = "Completed ✓";
    } else {
      row.className = "";
      statusCell.textContent = "Upcoming";
      if (nextIdx === -1 && now < start) {
        nextIdx = index;
      }
    }
  });

  renderClassrooms();

  // Attendance Alert Logic:
  // Index 2  = 2nd Period (08:25 - 09:20) -> Hero Ninja Alert 🥷
  // Index 10 = 7th Period (14:15 - 15:10) -> Round 2 Hero Fan Alert 🪭
  const banner = document.getElementById('attendance-alert');
  const bannerText = document.getElementById('banner-text');
  const bannerIcon = document.getElementById('banner-icon');

  if (currentIdx === 2) {
    bannerIcon.textContent = "🥷";
    bannerText.innerHTML = "<strong>IMPORTANT:</strong> Check the attendance, hero! 🥷";
    if (dismissedSessionIndex !== 2) {
      banner.style.display = 'flex';
    }
  } else if (currentIdx === 10) {
    bannerIcon.textContent = "🪭";
    bannerText.innerHTML = "<strong>ROUND 2:</strong> Check the attendance, hero! 🪭";
    if (dismissedSessionIndex !== 10) {
      banner.style.display = 'flex';
    }
  } else {
    banner.style.display = 'none';
    if (currentIdx !== 2 && currentIdx !== 10) {
      dismissedSessionIndex = -1;
    }
  }

  // Current Session Card
  if (currentIdx !== -1) {
    const current = schedule[currentIdx];
    const end = parseTime(current.end);
    document.getElementById('current-session-title').innerHTML = `${current.icon} ${current.name}`;
    document.getElementById('current-range').textContent = `${formatAmPm(current.start)} - ${formatAmPm(current.end)}`;
    document.getElementById('current-countdown').textContent = formatTimeRemaining(end - now);
  } else {
    document.getElementById('current-session-title').innerHTML = `☕ Off Schedule`;
    document.getElementById('current-range').textContent = `--:--`;
    document.getElementById('current-countdown').textContent = `--:--`;
  }

  // Next Session Card
  if (nextIdx !== -1 && nextIdx < schedule.length) {
    const next = schedule[nextIdx];
    const start = parseTime(next.start);
    document.getElementById('next-session-title').innerHTML = `${next.icon} ${next.name}`;
    document.getElementById('next-range').textContent = formatAmPm(next.start);
    document.getElementById('next-countdown').textContent = formatTimeRemaining(start - now);
  } else {
    document.getElementById('next-session-title').innerHTML = `🏁 End of Day`;
    document.getElementById('next-range').textContent = `--:--`;
    document.getElementById('next-countdown').textContent = `00:00`;
  }
}

function toggleTheme() {
  const html = document.documentElement;
  const btn = document.getElementById('theme-btn');
  const isDark = html.getAttribute('data-theme') === 'dark';
  
  if (isDark) {
    html.setAttribute('data-theme', 'light');
    btn.textContent = '🌙 Dark';
  } else {
    html.setAttribute('data-theme', 'dark');
    btn.textContent = '☀️ Light';
  }
}

// Initial Run
renderTable();
renderClassrooms();
updateDashboard();
setInterval(updateDashboard, 1000);
